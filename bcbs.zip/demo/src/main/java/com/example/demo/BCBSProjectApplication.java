package com.example.demo;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController

/* This class keeps track of the information for a sales receipt,
 * which is a String that lists the names and costs of individual items that 
 * have been purchased, and the total of all costs for items on the receipt. */

public class BCBSProjectApplication{

	private String receipt;
	private double total;
	
	/* Constructor. */
	public BCBSProjectApplication() { 
	   receipt = "";
	   total = 0.0;
	}
 
	/* This method adds the name and cost of an item to the receipt and the cost to the running total. */
	public void addNewItem(String name, double cost) {
	   receipt = receipt + (name + ":\t" + cost + "\n");
	   total = total + cost;
	}
 
	/* This method returns the receipt you have so far. It returns a String representing the receipt. */
	public String getReceipt() {
	   return receipt;
	}
	
	/* This method returns the running total. It returns a double representing the total price for the receipt. */
	public double getTotal() {
	   return total;
	}
	
	/* This method resets the instance variables to their default values. */
	public void reset() {
	   this.receipt = "";
	   this.total = 0.0;
	}
  
   // The main method.
   public static void main(String[] args){
	SpringApplication.run(BCBSProjectApplication.class, args);
    Scanner scan = new Scanner(System.in);
    
	BCBSProjectApplication receiptGen = new BCBSProjectApplication();
   
      System.out.println("Welcome to the receipt generator!");
      int userAnswer = -1;

      while(userAnswer != 5) {
         System.out.println("Would you like to:");
         System.out.println("\t1) Add an item to the receipt");
         System.out.println("\t2) Print your receipt");
         System.out.println("\t3) Print your total cost");
         System.out.println("\t4) Reset the calculator");
         System.out.println("\t5) Quit");
         
         userAnswer = Integer.parseInt(scan.nextLine());
         
         // If the user wants to add an item to the calculation:
         if(userAnswer == 1){
            System.out.println("Please enter the name of your item:"); 
            String name = scan.nextLine();
            
            System.out.println("Please enter the price of your item:"); 
            double cost = Double.parseDouble(scan.nextLine());
            
            /* Telling the generator to add it to the receipt's running total and take the total price calculated and print it */
            receiptGen.addNewItem(name, cost);
            double totalCost = receiptGen.getTotal(); 
            System.out.println("Your current total is: " + totalCost);
         }
         // If the user wants to print their receipt
         else if(userAnswer == 2){
            System.out.println("Your current receipt: ");
            System.out.println(receiptGen.getReceipt());
         }
         // If the user wants to print their total
         else if(userAnswer == 3){
            System.out.println("Your current total is: " + receiptGen.getTotal());
         }
         // If the user wants to reset their calculations
         else if(userAnswer == 4){
            receiptGen.reset();
            System.out.println("Calculator has been reset");
         }
          
      } // End of while loop
      
      System.out.println("Goodbye!");
   }
}